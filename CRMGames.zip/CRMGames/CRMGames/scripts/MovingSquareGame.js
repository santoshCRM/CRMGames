﻿var myGamePiece;
var myUpBtn;
var myDownBtn;
var myLeftBtn;
var myRightBtn;
var myObstacles = [];
var myScore;
var myRestart;
function restart()
{
    myGameArea.stop();
    myObstacles = [];
    myGameArea.clear();
    myGameArea.frameNo = 0;
    myGameArea.start();
}
function startGame() {
  
    myGamePiece = new component(30, 30, "red", 10, 120);
    myScore = new component("30px", "Consolas", "black", 280, 40, "text");
    myUpBtn = new component(30, 30, "#d8d0dd", 400, 50);
    myDownBtn = new component(30, 30, "#d8d0dd", 400, 110);
    myLeftBtn = new component(30, 30, "#d8d0dd", 370, 80);
    myRightBtn = new component(30, 30, "#d8d0dd", 430, 80);
    myObstacles = [];
    myGameArea.start();
}

var myGameArea = {
    canvas: document.createElement("canvas"),
    start: function () {
        this.canvas.width = 480;
        this.canvas.height = 270;
        this.context = this.canvas.getContext("2d");
        document.body.insertBefore(this.canvas, document.body.childNodes[0]);
        this.frameNo = 0;
        this.interval = setInterval(updateGameArea, 20);
        window.addEventListener('mousedown', function (e) {
            myGameArea.x = e.pageX;
            myGameArea.y = e.pageY;
        })
        window.addEventListener('mouseup', function (e) {
            myGameArea.x = false;
            myGameArea.y = false;
        })
        window.addEventListener('touchstart', function (e) {
            myGameArea.x = e.pageX;
            myGameArea.y = e.pageY;
        })
        window.addEventListener('touchend', function (e) {
            myGameArea.x = false;
            myGameArea.y = false;
        })
        window.addEventListener('keydown', function (e) {
            myGameArea.keys = (myGameArea.keys || []);
            myGameArea.keys[e.keyCode] = true;
        })
        window.addEventListener('keyup', function (e) {
            myGameArea.keys[e.keyCode] = false;
        })
    },
    clear: function () {
        this.context = this.canvas.getContext('2d');
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    },
    stop: function () {
        clearInterval(this.interval);
    }
}
function everyinterval(n) {
    if ((myGameArea.frameNo / n) % 1 == 0) { return true; }
    return false;
}
function component(width, height, color, x, y, type) {
    this.type = type;
    if (type == "image") {
        this.image = new Image();
        this.image.src = color;
    }
    this.width = width;
    this.height = height;
    this.speedX = 0;
    this.speedY = 0;

    this.x = x;
    this.y = y;
    this.update = function () {
        ctx = myGameArea.context;
        if (type == "image") {
            ctx.drawImage(this.image,
              this.x,
              this.y,
              this.width, this.height);
        }
        else if (this.type == "text") {
            ctx.font = this.width + " " + this.height;
            ctx.fillStyle = color;
            ctx.fillText(this.text, this.x, this.y);
        } else {
            ctx.fillStyle = color;
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }
    }
    this.clicked = function () {
        var myleft = this.x;
        var myright = this.x + (this.width);
        var mytop = this.y;
        var mybottom = this.y + (this.height);
        var clicked = true;
        if ((mybottom < myGameArea.y) || (mytop > myGameArea.y) || (myright < myGameArea.x) || (myleft > myGameArea.x)) {
            clicked = false;
        }
        return clicked;
    }
    this.newPos = function () {
        this.x += this.speedX;
        this.y += this.speedY;
    }
    this.crashWith = function (otherobj) {
        var myleft = this.x;
        var myright = this.x + (this.width);
        var mytop = this.y;
        var mybottom = this.y + (this.height);
        var otherleft = otherobj.x;
        var otherright = otherobj.x + (otherobj.width);
        var othertop = otherobj.y;
        var otherbottom = otherobj.y + (otherobj.height);
        var crash = true;
        if ((mybottom < othertop) ||
               (mytop > otherbottom) ||
               (myright < otherleft) ||
               (myleft > otherright)) {
            crash = false;
        }
        return crash;
    }
}
function updateGameArea() {
    var x, y;
    
    for (i = 0; i < myObstacles.length; i += 1) {
        if (myGamePiece.crashWith(myObstacles[i])) {
            myGameArea.stop();
            return;
        }
    }

   
        myGameArea.clear();
        myGameArea.frameNo += 1;
        if (myGameArea.frameNo == 1 || everyinterval(150)) {
            x = myGameArea.canvas.width;
            minHeight = 20;
            maxHeight = 200;
            height = Math.floor(Math.random() * (maxHeight - minHeight + 1) + minHeight);
            minGap = 50;
            maxGap = 200;
            gap = Math.floor(Math.random() * (maxGap - minGap + 1) + minGap);
            myObstacles.push(new component(10, height, "green", x, 0));
            myObstacles.push(new component(10, x - height - gap, "green", x, height + gap));
        }
        for (i = 0; i < myObstacles.length; i += 1) {
            myObstacles[i].x += -1;
            myObstacles[i].update();
        }

      
        if (myGameArea.x && myGameArea.y) {
            if (myUpBtn.clicked()) {
                myGamePiece.y -= 1;
            }
            if (myDownBtn.clicked()) {
                myGamePiece.y += 1;
            }
            if (myLeftBtn.clicked()) {
                myGamePiece.x += -1;
            }
            if (myRightBtn.clicked()) {
                myGamePiece.x += 1;
            }
           
        }
        if (myGameArea.keys && myGameArea.keys[37]) {
            myGamePiece.speedX = 0;
            myGamePiece.speedY = 0;
            myGamePiece.speedX = -1;
            myGamePiece.newPos();
        }
        if (myGameArea.keys && myGameArea.keys[39]) {
            myGamePiece.speedX = 0;
            myGamePiece.speedY = 0;
            myGamePiece.speedX = 1;
            myGamePiece.newPos();
        }
        if (myGameArea.keys && myGameArea.keys[38]) {
            myGamePiece.speedX = 0;
            myGamePiece.speedY = 0;
            myGamePiece.speedY = -1; myGamePiece.newPos();
        }
        if (myGameArea.keys && myGameArea.keys[40]) {
            myGamePiece.speedX = 0;
            myGamePiece.speedY = 0;
            myGamePiece.speedY = 1; myGamePiece.newPos();
        }
        myUpBtn.update();
        myDownBtn.update();
        myLeftBtn.update();
        myRightBtn.update();
      
            myScore.text = "SCORE: " +  myGameArea.frameNo;
        myScore.update();
        myGamePiece.update();
   
}